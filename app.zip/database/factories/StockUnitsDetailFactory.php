<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\StockUnitsDetail;
use Faker\Generator as Faker;

$factory->define(StockUnitsDetail::class, function (Faker $faker) {
    return [
        //
    ];
});
