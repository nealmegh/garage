<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\PurchaseProductList;
use Faker\Generator as Faker;

$factory->define(PurchaseProductList::class, function (Faker $faker) {
    return [
        //
    ];
});
