<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\StockSale;
use Faker\Generator as Faker;

$factory->define(StockSale::class, function (Faker $faker) {
    return [
        //
    ];
});
