<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\damage;
use Faker\Generator as Faker;

$factory->define(damage::class, function (Faker $faker) {
    return [
        //
    ];
});
