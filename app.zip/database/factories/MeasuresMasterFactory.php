<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\MeasuresMaster;
use Faker\Generator as Faker;

$factory->define(MeasuresMaster::class, function (Faker $faker) {
    return [
        //
    ];
});
