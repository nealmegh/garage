<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\InventoryTransaction;
use Faker\Generator as Faker;

$factory->define(InventoryTransaction::class, function (Faker $faker) {
    return [
        //
    ];
});
