<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\VehicleDetails;
use Faker\Generator as Faker;

$factory->define(VehicleDetails::class, function (Faker $faker) {
    return [
        //
    ];
});
