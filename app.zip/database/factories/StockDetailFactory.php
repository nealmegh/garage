<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\StockDetail;
use Faker\Generator as Faker;

$factory->define(StockDetail::class, function (Faker $faker) {
    return [
        //
    ];
});
