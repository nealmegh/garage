<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Incident;
use Faker\Generator as Faker;

$factory->define(Incident::class, function (Faker $faker) {
    return [
        //
    ];
});
