<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\CustomerDetail;
use Faker\Generator as Faker;

$factory->define(CustomerDetail::class, function (Faker $faker) {
    return [
        //
    ];
});
