<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\SalesDetail;
use Faker\Generator as Faker;

$factory->define(SalesDetail::class, function (Faker $faker) {
    return [
        //
    ];
});
