<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\UnitOfMeasuresMaster;
use Faker\Generator as Faker;

$factory->define(UnitOfMeasuresMaster::class, function (Faker $faker) {
    return [
        //
    ];
});
