<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\CategoryUnitsMaster;
use Faker\Generator as Faker;

$factory->define(CategoryUnitsMaster::class, function (Faker $faker) {
    return [
        //
    ];
});
