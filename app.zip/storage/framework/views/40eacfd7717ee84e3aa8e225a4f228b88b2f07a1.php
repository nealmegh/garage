<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h3 class="title-5 m-b-35">Drivers Table</h3>
            <div class="table-data__tool">
                <div class="table-data__tool-right">
                    <a href="<?php echo e(route('driver.create')); ?>" class="au-btn au-btn-icon au-btn--green au-btn--small"><i class="zmdi zmdi-plus"></i>add Driver</a>
                </div>

            </div>
            <div class="table-responsive table-responsive-data2">
                <table class="table table-data2">
                    <thead>
                    <tr>
                        <th>
                            <label class="au-checkbox">
                                <input type="checkbox">
                                <span class="au-checkmark"></span>
                            </label>
                        </th>
                        <th>name</th>

                        <th>License</th>
                        <th>License Validity</th>
                        <th>Phone Number</th>
                        <th>Total Due</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="tr-shadow">
                        <td>
                            <label class="au-checkbox">
                                <input type="checkbox">
                                <span class="au-checkmark"></span>
                            </label>
                        </td>
                        <td><?php echo e($driver->user->name); ?></td>



                        <td class="desc"><?php echo e($driver->license_number); ?></td>
                        <td><?php echo e($driver->license_validity); ?></td>
                        <td>
                            <span class="status--process"><?php echo e($driver->phone_number); ?></span>
                        </td>
                        <?php
                        $loans = $driver->loans->sum('due_amount');
                        $due = $driver->rents->sum('due');
                        $damage = $driver->damages->sum('due_amount');
                        $total_due = $loans + $due + $damage;
                        ?>
                        <td><?php echo e($total_due); ?></td>
                        <td>
                            <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#<?php echo e($driver->id); ?>">
                                Show
                            </button>
                        </td>
                    </tr>
                    <tr class="spacer"></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Current Projects\ISP MGT\stack-n\resources\views/backend/driver/index.blade.php ENDPATH**/ ?>