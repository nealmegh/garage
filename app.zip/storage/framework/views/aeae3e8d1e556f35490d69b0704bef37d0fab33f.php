<?php $__env->startSection('content'); ?>

        <div class="card">
            <div class="card-header">
                Create <strong>Vehicle</strong>
            </div>
            <div class="card-body card-block">
                <form action="" method="post" enctype="multipart/form-data" class="form-horizontal">

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="select" class=" form-control-label">Select Vehicle Type</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <select name="select" id="select" class="form-control">
                                <option value="0">Please select</option>
                                <option value="1">CNG</option>
                                <option value="2">Micro-Bus</option>
                                <option value="3">Sedan</option>
                            </select>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="text-input" class=" form-control-label">Registration Number</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="registration_number" name="registration_number" placeholder="" class="form-control">
                            <small class="form-text text-muted">Eg. Dhaka Metro La 15-3593</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="email-input" class=" form-control-label">Registration Validity</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="registration_validity" name="registration_validity" placeholder="Enter Date" class="form-control">
                            <small class="help-block form-text">Last Valid Date</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="text-input" class=" form-control-label">Route Permit Number</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="route_permit_number" name="route_permit_number" placeholder="Text" class="form-control">
                            <small class="form-text text-muted">Eg. 122211</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="email-input" class=" form-control-label">Route Permit Validity</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="route_permit_validity" name="route_permit_validity" placeholder="Enter Date" class="form-control">
                            <small class="help-block form-text">Last Valid Date</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="text-input" class=" form-control-label">Fitness Number</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="fitness_number" name="fitness_number" placeholder="Text" class="form-control">
                            <small class="form-text text-muted">Eg. Dhaka Metro La 15-3593</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="email-input" class=" form-control-label">Fitness Validity</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="fitness_validity" name="fitness_validity" placeholder="Enter Date" class="form-control">
                            <small class="help-block form-text">Last Valid Date</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="text-input" class=" form-control-label">Insurance Number</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="insurance_number" name="insurance_number" placeholder="Text" class="form-control">
                            <small class="form-text text-muted">Eg. Dhaka Metro La 15-3593</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="email-input" class=" form-control-label">Insurance Validity</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="insurance_validity" name="insurance_validity" placeholder="Enter Date" class="form-control">
                            <small class="help-block form-text">Last Valid Date</small>
                        </div>
                    </div>

















                </form>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-primary btn-sm">
                    <i class="fa fa-dot-circle-o"></i> Submit
                </button>
                <button type="reset" class="btn btn-danger btn-sm">
                    <i class="fa fa-ban"></i> Reset
                </button>
            </div>
        </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

   <script>
       $( "#registration_validity" ).datepicker({
       });
       $( "#route_permit_validity" ).datepicker({
       });
       $( "#fitness_validity" ).datepicker({
       });
       $( "#insurance_validity" ).datepicker({
       });

   </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Current Projects\ISP MGT\stack-n\resources\views/backend/cng/create.blade.php ENDPATH**/ ?>