<?php $__env->startSection('content'); ?>

        <div class="card">
            <div class="card-header">
                Create <strong>Driver</strong>
            </div>
            <div class="card-body card-block">
                <form action="<?php echo e(route('driver.store')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                    <?php echo csrf_field(); ?>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="name" class=" form-control-label">Name</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="name" name="name" placeholder="" class="form-control">

                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="nid" class=" form-control-label">NID</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="nid" name="nid" placeholder="Enter NID" class="form-control"  >
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="phone_number" class=" form-control-label">Phone Number</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="phone_number" minlength="11" name="phone_number" placeholder="Phone" class="form-control" required>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="license_number" class=" form-control-label">License Number</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="license_number" minlength="15" name="license_number" placeholder="License" class="form-control" required>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="license_validity" class=" form-control-label">License Validity</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="license_validity" name="license_validity" placeholder="Enter Date" class="form-control date" required>
                            <small class="help-block form-text">Last Valid Date</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="license_photo" class=" form-control-label">License Photo</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="file" id="license_photo" name="license_photo"  class="form-control " >
                            <small class="help-block form-text">Driving License Photo</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="license_photo" class=" form-control-label">NID Photo</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="file" id="nid_photo" name="nid_photo"  class="form-control " >
                            <small class="help-block form-text">NID Photo</small>
                        </div>
                    </div>

















                    <div class="card-footer">
                        <button type="submit" value="submit" class="btn btn-primary btn-sm">
                            <i class="fa fa-dot-circle-o"></i> Submit
                        </button>
                        <button type="reset" class="btn btn-danger btn-sm">
                            <i class="fa fa-ban"></i> Reset
                        </button>
                    </div>
                </form>
            </div>

        </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
    var nowDate = new Date();
    var today = new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 0, 0, 0, 0);
    $(function() {
        $('#license_validity').daterangepicker({
            singleDatePicker: true,
            showDropdowns: true,
            minDate: today,
            locale: {
                format: 'MM/DD/YYYY',
                separator: ' - ',
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Current Projects\ISP MGT\stack-n\resources\views/backend/driver/create.blade.php ENDPATH**/ ?>