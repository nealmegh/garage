<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h3 class="title-5 m-b-35">Purchase Table</h3>
            <div class="table-data__tool">
                <div class="table-data__tool-right">
                    <a href="<?php echo e(route('purchase.create')); ?>" class="au-btn au-btn-icon au-btn--green au-btn--small"><i class="zmdi zmdi-plus"></i>add Purchase</a>
                </div>

            </div>
            <div class="table-responsive table-responsive-data2">
                <table class="table table-data2">
                    <thead>
                    <tr>
                        <th>
                            <label class="au-checkbox">
                                <input type="checkbox">
                                <span class="au-checkmark"></span>
                            </label>
                        </th>
                        <th>Purchase ID</th>
                        <th>Supplier</th>
                        <th>Grand Total</th>
                        <th>Closing Due</th>
                        <th>Closing Balance</th>


                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="tr-shadow">
                        <td>
                            <label class="au-checkbox">
                                <input type="checkbox">
                                <span class="au-checkmark"></span>
                            </label>
                        </td>
                        <td><?php echo e($purchase->id); ?></td>
                        <td>
                            <span class="block-email"><?php echo e($purchase->supplier_name); ?></span>
                        </td>
                        <td class="desc"><?php echo e($purchase->grand_total); ?></td>
                        <td><?php echo e($purchase->closing_due); ?></td>
                        <td>
                            <span class="status--process"><?php echo e($purchase->closing_balance); ?></span>
                        </td>



                        <td>
                            <a href="/stock/edit/<?php echo e($purchase->id); ?>" data-toggle="tooltip" title="Edit"> <i class="fa fa-pencil-square-o" aria-hidden="true"></i> </a>

                        </td>
                    </tr>
                    <tr class="spacer"></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Current Projects\ISP MGT\stack-n\resources\views/purchase/index.blade.php ENDPATH**/ ?>