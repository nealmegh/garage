<?php $__env->startSection('head'); ?>
    <style>
        .modal-backdrop {
            /* bug fix - no overlay */
            display: none;
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h3 class="title-5 m-b-35">Transactions</h3> <h2>Cash In Hand: <?php echo e($total_amount); ?></h2>
            <div class="table-data__tool">
                <div class="table-data__tool-right">
                    <button type="button" class="btn btn-info" data-toggle="modal" data-target="#withdrawMoney">
                        Withdraw Money
                    </button>
                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#loanPayment">
                        Loan Payment
                    </button>
                    <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#rent">
                        Damage Payment
                    </button>
                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#loan">
                        Loan
                    </button>
                    <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#rent">
                        Regular Expense
                    </button>
                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#rent">
                        Cash Payments
                    </button>
                    <button type="button" style="margin-top: 7px;" class="btn btn-info" data-toggle="modal" data-target="#addMoney">
                        Add Money
                    </button>
                </div>

            </div>
            <div class="table-responsive table-responsive-data2">
                <table class="table table-data2">
                    <thead>
                    <tr>
                        <th>
                            <label class="au-checkbox">
                                <input type="checkbox">
                                <span class="au-checkmark"></span>
                            </label>
                        </th>
                        <th>ID</th>
                        <th>Type</th>
                        <th>Method</th>
                        <th>Payment For</th>
                        <th>Vehicle No</th>
                        <th>Driver</th>
                        <th>Amount</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="tr-shadow">
                            <td>
                                <label class="au-checkbox">
                                    <input type="checkbox">
                                    <span class="au-checkmark"></span>
                                </label>
                            </td>
                            <td>
                                <?php echo e($transaction->id); ?>

                            </td>
                            <td>
                                <span class="block-email"><?php echo e($transaction->type); ?></span>
                            </td>
                            <td class="desc"><?php echo e($transaction->method); ?></td>
                            <td><?php echo e($transaction->payment_for); ?></td>
                            <?php if($transaction->rent != null): ?>
                                <td><?php echo e($transaction->rent->vehicle->registration_number); ?></td>
                            <?php else: ?>
                                <td>N/A</td>
                            <?php endif; ?>
                            <?php if($transaction->driver != null): ?>
                                <td><?php echo e($transaction->driver->user->name); ?></td>
                            <?php else: ?>
                                <td>N/A</td>
                            <?php endif; ?>
                            <td><?php echo e($transaction->amount); ?></td>
                        </tr>
                        <tr class="spacer"></tr>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Current Projects\ISP MGT\stack-n\resources\views/backend/transactions/index.blade.php ENDPATH**/ ?>