<div class="sidebar-wrapper sidebar-theme">

    <nav id="sidebar">
        <div class="profile-info">
            <figure class="user-cover-image"></figure>
            <div class="user-info">
                <img src="<?php echo e(asset('/images/icon/avatar-01.jpg')); ?>" alt="avatar">
                <h6 class=""><?php echo e(Auth::user()->name); ?></h6>
                <p class=""><?php echo e(Auth::user()->roles->first()->name); ?></p>
            </div>
        </div>

        <div class="shadow-bottom"></div>
        <ul class="list-unstyled menu-categories" id="accordionExample">
            <li class="menu <?php echo e((request()->is('dashboard*')) ? 'active' : ''); ?>">
                <a href="#dashboard" data-toggle="collapse" aria-expanded="<?php echo e((request()->is('dashboard*')) ? 'true' : 'false'); ?>" class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                        <span>Dashboard</span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </a>
                <ul class="collapse submenu recent-submenu mini-recent-submenu list-unstyled show" id="dashboard" data-parent="#accordionExample">
                    <li class="<?php echo e((request()->is('dashboard')) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('dashboard')); ?>"> Main Dashboard </a>
                    </li>
                    <li class="<?php echo e((request()->is('dashboard/reports*')) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('reports.index')); ?>"> Reports </a>
                    </li>
                </ul>
            </li>


            <li class="menu menu-heading">
                <div class="heading"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-minus"><line x1="5" y1="12" x2="19" y2="12"></line></svg><span>Vehicle Management</span></div>
            </li>

            <li class="menu <?php echo e((request()->is('rent*')) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('rent.index')); ?>"  aria-expanded="<?php echo e((request()->is('rent*')) ? 'true' : 'false'); ?>" class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-calendar"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>

                        <span>Rents</span>
                    </div>
                </a>

            </li>


            <li class="menu <?php echo e((request()->is('vehicle*')) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('vehicle.index')); ?>"  aria-expanded="<?php echo e((request()->is('vehicle*')) ? 'true' : 'false'); ?>" class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-truck"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>

                        <span>Vehicles</span>
                    </div>
                </a>
            </li>

            <li class="menu <?php echo e((request()->is('case*')) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('case.index')); ?>"  aria-expanded="<?php echo e((request()->is('case*')) ? 'true' : 'false'); ?>" class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x-octagon"><polygon points="7.86 2 16.14 2 22 7.86 22 16.14 16.14 22 7.86 22 2 16.14 2 7.86 7.86 2"></polygon><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>


                        <span>Cases</span>
                    </div>
                </a>
            </li>
            <li class="menu <?php echo e((request()->is('damage*')) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('damage.index')); ?>" aria-expanded="<?php echo e((request()->is('damage*')) ? 'true' : 'false'); ?>" class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-alert-triangle"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>


                        <span>Damage</span>
                    </div>
                </a>
            </li>

            <li class="menu menu-heading">
                <div class="heading"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-minus"><line x1="5" y1="12" x2="19" y2="12"></line></svg><span>User Management</span></div>
            </li>

            <li class="menu <?php echo e((request()->is('user*')) ? 'active' : ''); ?>">
                <a href="#users" data-toggle="collapse" aria-expanded="<?php echo e((request()->is('user*')) ? 'true' : 'false'); ?>" class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-users"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>

                        <span>Users</span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="users" data-parent="#accordionExample">
                    <li <?php echo e((request()->is('user*')) ? 'active' : ''); ?>>
                        <a href="<?php echo e(url('users')); ?>"> Users </a>
                    </li>
                    <li>
                        <a href="#"> Roles  </a>
                    </li>
                    <li>
                        <a href="#"> Permissions </a>
                    </li>
                </ul>
            </li>

            <li class="menu <?php echo e((request()->is('driver*')) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('driver.index')); ?>" aria-expanded="<?php echo e((request()->is('driver*')) ? 'true' : 'false'); ?>" class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user-plus"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="20" y1="8" x2="20" y2="14"></line><line x1="23" y1="11" x2="17" y2="11"></line></svg>

                        <span>Drivers</span>
                    </div>
                </a>
            </li>
            <li class="menu <?php echo e((request()->is('owner*')) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('owner.index')); ?>" aria-expanded="<?php echo e((request()->is('owner*')) ? 'true' : 'false'); ?>" class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user-check"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><polyline points="17 11 19 13 23 9"></polyline></svg>

                        <span>Owners</span>
                    </div>
                </a>
            </li>


            <li class="menu menu-heading">
                <div class="heading"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-minus"><line x1="5" y1="12" x2="19" y2="12"></line></svg><span>Finance Management</span></div>
            </li>

            <li class="menu <?php echo e((request()->is('transactions*')) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('transaction.index')); ?>" aria-expanded="<?php echo e((request()->is('transactions')) ? 'true' : 'false'); ?>" class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-dollar-sign"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>

                        <span>Transactions</span>
                    </div>
                </a>
            </li>

            <li class="menu menu-heading">
                <div class="heading"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-minus"><line x1="5" y1="12" x2="19" y2="12"></line></svg><span>Inventory Management</span></div>
            </li>

            <li class="menu <?php echo e((request()->is('inventory*')) ? 'active' : ''); ?>">
                <a href="#inventory" data-toggle="collapse" aria-expanded="<?php echo e((request()->is('inventory*')) ? 'true' : 'false'); ?>" class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-archive"><polyline points="21 8 21 21 3 21 3 8"></polyline><rect x="1" y="3" width="22" height="5"></rect><line x1="10" y1="12" x2="14" y2="12"></line></svg>

                        <span>Inventory</span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="inventory" data-parent="#accordionExample">
                    <li class="<?php if(Request::is('category*')): ?> active <?php endif; ?>">
                        <a href="<?php echo e(route('category.index')); ?>">
                            Category
                        </a>
                    </li>
                    <li class=" <?php if(Request::is('stock*')): ?> active <?php endif; ?>">
                        <a href="<?php echo e(route('stock.index')); ?>">
                            Stock/Product
                        </a>
                    </li>
                    <li class=" <?php if(Request::is('supplier*')): ?> active <?php endif; ?>">
                        <a href="<?php echo e(route('supplier.index')); ?>">
                            Supplier
                        </a>
                    </li>
                    <li class=" <?php if(Request::is('purchase*')): ?> active <?php endif; ?>">
                        <a href="<?php echo e(route('purchase.index')); ?>">
                            Purchase
                        </a>
                    </li>

                    <li class=" <?php if(Request::is('sales*')): ?> active <?php endif; ?>">
                        <a href="<?php echo e(route('sales.index')); ?>">
                            Sales
                        </a>
                    </li>

                    <li class=" <?php if(Request::is('customer*')): ?> active <?php endif; ?>">
                        <a href="<?php echo e(route('customer.index')); ?>">
                            Customer
                        </a>
                    </li>
                </ul>
            </li>

        </ul>
    </nav>
</div>
<?php /**PATH D:\Current Projects\CNG Project\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>