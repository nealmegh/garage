
<!-- Modal -->
<?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="rent<?php echo e($rent->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">End Trip</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('rent.end')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                    <?php echo csrf_field(); ?>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="rent" class=" form-control-label">Rent</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="rent" name="rent" placeholder="Rent" class="form-control" value="<?php echo e($rent->rent); ?>" disabled>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="gate" class=" form-control-label">Gate Charge</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="gate" name="gate" placeholder="Gate Charge" class="form-control" value="<?php echo e(20.00); ?>" disabled>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="discount" class=" form-control-label">Discount</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="number" id="discount" name="discount" placeholder="Discount" class="form-control" value="" >
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="collection" class=" form-control-label">Collection</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="number" id="collection" name="collection" placeholder="Collection" class="form-control">
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="case" class=" form-control-label">Case</label>
                        </div>
                        <div class="col-12 col-md-9">

                            <input type="checkbox" id="toggle-case" name="case" value="yes" onclick="toggle('.case_yes', this)" >
                        </div>
                    </div>
                    <div id="case_yes" class="case_yes" style="display: none">
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="case_id" class=" form-control-label">Case ID</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="case_id" name="case_id" placeholder="Case ID" class="form-control">
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="penalty" class=" form-control-label">Penalty Amount</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="penalty" name="penalty" placeholder="Penalty Amount" class="form-control">
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="law" class=" form-control-label">Law Section</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="law" name="law" placeholder="Law Section" class="form-control">
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="doc_type" class=" form-control-label">Ceased Doc Type</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <select name="doc_type" id="doc_type" class="form-control">
                                <option value="0">Please select</option>
                                <option value="registration"><?php echo e('Registration Paper'); ?></option>
                                <option value="driving"><?php echo e('Driving License'); ?></option>
                                <option value="fitness"><?php echo e('Fitness'); ?></option>
                                <option value="insurance"><?php echo e('Insurance'); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="last_date" class=" form-control-label">Last Date</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="last_date" name="last_date" placeholder="Last Date" class="form-control date">
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="paid_by" class=" form-control-label">Paid By</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <select name="paid_by" id="paid_by" class="form-control">
                                <option value="0">Please select</option>
                                <option value="driver"><?php echo e($rent->driver->user->name); ?></option>
                                <option value="owner"><?php echo e('Owner'); ?></option>
                            </select>
                        </div>
                    </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="damage" class=" form-control-label">Damage</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="checkbox" id="toggle-case" name="damage" value="yes" onclick="toggle('.damage_yes', this)" >
                        </div>
                    </div>
                    <div class="damage_yes" style="display:none;">
                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label for="damage_amount" class=" form-control-label">Damage Amount</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="damage_amount" name="damage_amount" placeholder="Damage Amount" class="form-control">
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="rent_id" value="<?php echo e($rent->id); ?>">

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    function toggle(className, obj) {
        if ( obj.checked ) $(className).show();
        else $(className).hide();
    }





</script>
<?php /**PATH D:\Current Projects\ISP MGT\stack-n\resources\views/layouts/endTripModal.blade.php ENDPATH**/ ?>