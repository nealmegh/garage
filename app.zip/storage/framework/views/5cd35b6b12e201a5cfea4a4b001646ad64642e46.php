<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if(Session::has('message')): ?>
    <div class="row">'
    <div class="col-md-offset-2 col-md-8">
      <div class="alert <?php if(Session::get('messageType') == 1): ?> alert-success <?php else: ?> alert-danger <?php endif; ?>">
        <?php echo e(Session::get('message')); ?>

      </div>
    </div>
    </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <h3 class="title-5 m-b-35">Category</h3>
            <div class="table-data__tool">
                <div class="table-data__tool-right">
                    <a href="<?php echo e(route('category.create')); ?>" class="au-btn au-btn-icon au-btn--green au-btn--small"><i class="zmdi zmdi-plus"></i>add Category</a>
                </div>

            </div>
            <div class="table-responsive table-responsive-data2">
                <table class="table table-data2">
                    <thead>
                    <tr>
                        <th>
                            <label class="au-checkbox">
                                <input type="checkbox">
                                <span class="au-checkmark"></span>
                            </label>
                        </th>
                        <th>Category Name</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="tr-shadow">
                            <td>
                                <label class="au-checkbox">
                                    <input type="checkbox">
                                    <span class="au-checkmark"></span>
                                </label>
                            </td>
                            <td><?php echo e($category->category_name); ?></td>
                            <td><a href="/category/edit/<?php echo e($category->id); ?>" data-toggle="tooltip" title="Edit"> <i class="fa fa-pencil-square-o" aria-hidden="true"></i> </a>
                                <a href="/category/destroy/<?php echo e($category->id); ?>" data-toggle="tooltip" title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></a>
                            </td>
                        </tr>
                        <tr class="spacer"></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Current Projects\ISP MGT\stack-n\resources\views/category/view.blade.php ENDPATH**/ ?>