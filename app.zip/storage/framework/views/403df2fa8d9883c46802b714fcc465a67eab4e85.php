
<!-- Modal -->
<?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $loans = $driver->loans->sum('due_amount');
        $due = $driver->rents->sum('due');
        $damage = $driver->damages->sum('due_amount');
        $total_due = $loans + $due + $damage;
    ?>
<div class="modal fade" id="<?php echo e($driver->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo e($driver->user->name); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="amount" class=" form-control-label">Rent Due </label>
                        </div>
                        <div class="col-12 col-md-9">
                            <label for="amount" class=" form-control-label"><?php echo e($due); ?></label>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="amount" class=" form-control-label">Loan Due</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <label for="amount" class=" form-control-label"><?php echo e($loans); ?></label>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="amount" class=" form-control-label">Damage Due</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <label for="amount" class=" form-control-label"><?php echo e($damage); ?></label>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="amount" class=" form-control-label">Total Due Amount</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <label for="amount" class=" form-control-label"><?php echo e($total_due); ?></label>
                        </div>
                    </div>
                <label class=" form-control-label">DL</label>
                <img src='<?php echo e(asset('storage/'.$driver->details->license_photo)); ?>'>
                <label class=" form-control-label">NID</label>
                <img src='<?php echo e(asset('storage/'.$driver->details->nid_photo)); ?>'>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
            </div>

        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH D:\Current Projects\ISP MGT\stack-n\resources\views/backend/driver/driverShowModal.blade.php ENDPATH**/ ?>