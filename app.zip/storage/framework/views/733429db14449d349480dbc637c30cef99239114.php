<?php $__env->startSection('head'); ?>
<style>
    .modal-backdrop {
        /* bug fix - no overlay */
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h3 class="title-5 m-b-35">Rents Table</h3>
            <div class="table-data__tool">
                <div class="table-data__tool-right">
                    <a href="<?php echo e(route('rent.create')); ?>" class="au-btn au-btn-icon au-btn--green au-btn--small"><i class="zmdi zmdi-plus"></i>add Rent</a>
                </div>

            </div>
            <div class="table-responsive table-responsive-data2">
                <table class="table table-data2">
                    <thead>
                    <tr>
                        <th>
                            <label class="au-checkbox">
                                <input type="checkbox">
                                <span class="au-checkmark"></span>
                            </label>
                        </th>
                        <th>Vehicle</th>
                        <th>Driver</th>
                        <th>Rent Type</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="tr-shadow">
                        <td>
                            <label class="au-checkbox">
                                <input type="checkbox">
                                <span class="au-checkmark"></span>
                            </label>
                        </td>
                        <td class="desc"><?php echo e($rent->vehicle->registration_number); ?></td>
                        <td>
                            <span class="block-email"><?php echo e($rent->driver->user->name); ?></span>
                        </td>
                        <td><?php if($rent->rent_type == 1): ?>
                                <?php echo e('1st Half'); ?>

                            <?php elseif($rent->rent_type == 2): ?>
                                <?php echo e('2nd Half'); ?>

                            <?php else: ?>
                                <?php echo e('Full Day'); ?>

                            <?php endif; ?>
                        </td>
                        <td><?php echo e($rent->start_time); ?></td>
                        <td >



                            <?php if($rent->end_time == '00:00:00'): ?>
                            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#rent<?php echo e($rent->id); ?>">
                                End Trip
                            </button>
                            <?php else: ?>
                                <?php echo e($rent->end_time); ?>

                            <?php endif; ?>

                        </td>
                        <td>
                            <?php if($rent->end_time == '00:00:00'): ?>
                                On-Going
                            <?php else: ?>
                                Completed
                            <?php endif; ?>
                        </td>

                    </tr>
                    <tr class="spacer"></tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script>
    function formatDate(date) {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    }
    var nowDate = new Date();
    nowDate.setDate(nowDate.getDate() + 21);
    var today = new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate() , 0, 0, 0, 0);

    var todayString = today.toDateString();
    var minDate = formatDate(todayString);

    $(function() {
        $('.date').daterangepicker({
            singleDatePicker: true,
            showDropdowns: true,
            minDate: today,
            locale: {
                format: 'MM/DD/YYYY'
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Current Projects\ISP MGT\stack-n\resources\views/backend/rent/index.blade.php ENDPATH**/ ?>