
<!-- Modal -->
<?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="modal fade" id="<?php echo e($vehicle->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo e($vehicle->registration_number); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <label class=" form-control-label">Registration</label>
                <img src='<?php echo e(asset('storage/'.$vehicle->details->registration_img)); ?>'>
                <label class=" form-control-label">Fitness</label>
                <img src='<?php echo e(asset('storage/'.$vehicle->details->fitness_img)); ?>'>
                <label class=" form-control-label">Tax</label>
                <img src='<?php echo e(asset('storage/'.$vehicle->details->tax_img)); ?>'>
                <label class=" form-control-label">Insurance</label>
                <img src='<?php echo e(asset('storage/'.$vehicle->details->insurance_img)); ?>'>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
            </div>

        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH D:\Current Projects\ISP MGT\stack-n\resources\views/backend/vehicle/vehicleShowModal.blade.php ENDPATH**/ ?>