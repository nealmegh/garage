<?php $__env->startSection('head'); ?>
    <!--  BEGIN CUSTOM STYLE FILE  -->
    <link href="<?php echo e(asset('base/assets/css/scrollspyNav.css')); ?>" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('base/plugins/select2/select2.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('base/plugins/bootstrap-select/bootstrap-select.min.css')); ?>">
    <link href="<?php echo e(asset('base/plugins/flatpickr/custom-flatpickr.css')); ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
    <link href="<?php echo e(asset('base/plugins/file-upload/file-upload-with-preview.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!--  END CUSTOM STYLE FILE  -->
    <style>
        .ui-autocomplete {
            position: absolute;
            top: 100%;
            left: 0;
            z-index: 1000;
            display: none;
            float: left;
            min-width: 160px;
            padding: 5px 0;
            margin: 2px 0 0;
            list-style: none;
            font-size: 14px;
            text-align: left;
            background-color: #ffffff;
            border: 1px solid #cccccc;
            border: 1px solid rgba(0, 0, 0, 0.15);
            border-radius: 4px;
            -webkit-box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);
            background-clip: padding-box;
        }

        .ui-autocomplete > li > div {
            display: block;
            padding: 3px 20px;
            clear: both;
            font-weight: normal;
            line-height: 1.42857143;
            color: #333333;
            white-space: nowrap;
        }

        .ui-state-hover,
        .ui-state-active,
        .ui-state-focus {
            text-decoration: none;
            color: #262626;
            background-color: #f5f5f5;
            cursor: pointer;
        }

        .ui-helper-hidden-accessible {
            border: 0;
            clip: rect(0 0 0 0);
            height: 1px;
            margin: -1px;
            overflow: hidden;
            padding: 0;
            position: absolute;
            width: 1px;
        }

    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-xl-12 col-lg-12 col-md-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
                <div class="row">
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                        <h4>Create <strong>Stock</strong></h4>
                    </div>
                </div>
            </div>
            <div class="widget-content widget-content-area">
            <form class="form-horizontal create_stock" role="form" method="POST" action="<?php echo e(route('stock.store')); ?>">
                <?php echo csrf_field(); ?>

                <div class="box-body">

                    <div class="row">

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Stock Category</label>
                                <input type="text" class="form-control search_category_name" placeholder="Type here ..." name="category_name" autocomplete="off">
                                <span class="help-block search_category_name_empty" style="display: none;">No Results Found ...</span>
                                <input type="hidden" class="search_category_id" name="category_id">
                            </div>
                        </div>

                    </div>

                    <div class="row">

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Stock/Product Name</label>
                                <input type="text" class="form-control" placeholder="Type here ..." name="stock_name">
                            </div>
                        </div>

                    </div>
                    <div class="row">

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Initial Stock</label>
                                <input type="number" class="form-control" placeholder="Type here ..." name="stock_quantity">
                            </div>
                        </div>

                    </div>

                    <div class="row">


                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Purchase Cost / Unit</label><br>
                                <input type="text" class="form-control" name="purchase_cost" placeholder="0.00">
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Selling Cost / Unit</label>
                                <input type="text" class="form-control" name="selling_cost" placeholder="0.00">
                            </div>
                        </div>

                    </div>

                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="unit_type">Unit Type</label><br>
                                <select class="form-control change_supplier_name selectpicker" name="unit_type" id="unit_type">
                                    <option selected="" disabled="" value=""> Select </option>
                                    <option value="kg">Kilograms</option>
                                    <option value="lt">Liters</option>
                                    <option value="pcs">Pieces</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">



                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="supplier_id">Supplier Name</label><br>
                                <select class="form-control change_supplier_name selectpicker" name="supplier_id" id="supplier_id" data-live-search="true">
                                    <option selected="" disabled="" value=""> Select </option>
                                    <option value="0">- Multiple suppliers -</option>
                                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value->id); ?>"><?php echo e($value->supplier_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="hidden" name="supplier_name" class="supplier_name">
                            </div>
                        </div>



                    </div>


                </div>
                <!-- /.box-body -->

                <div class="box-footer">
                    <button type="reset" class="btn btn-danger pull-left">Reset</button>
                    <button type="submit" class="btn btn-primary pull-right"><i class="fa fa-plus"></i> Add</button>
                </div>
            </form>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!--  BEGIN CUSTOM SCRIPTS FILE  -->
    <script src="<?php echo e(asset('base/assets/js/scrollspyNav.js')); ?>"></script>
    <script src="<?php echo e(asset('base/plugins/select2/select2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('base/plugins/bootstrap-select/bootstrap-select.min.js')); ?>"></script>


    <script src="<?php echo e(asset('base/plugins/file-upload/file-upload-with-preview.min.js')); ?>"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

    <script>
        //First upload
        // var firstUpload = new FileUploadWithPreview('photo')
    </script>
    <!--  BEGIN CUSTOM SCRIPTS FILE  -->
    <script>
        $( ".search_category_name" ).autocomplete({
            source: "/search/category_name",
            minLength: 1,
            response: function(event, ui) {
                if (ui.content.length === 0) {

                    $(this).parent().addClass('has-error');
                    $(this).next().removeClass('glyphicon-ok').addClass('glyphicon-remove');
                    $(".search_category_name_empty").show();
                    $('.form_submit').hide();

                } else {
                    $(".search_category_name_empty").hide();
                    $('.form_submit').show();
                }
            },
            select: function(event, ui) {

                $('.search_category_id').val(ui.item.id);

            }
        });
        $('.change_supplier_name').on('change' ,function(){

            if($(this).find(':selected').val() === 0){
                $('.supplier_name').val('');
            }
            else{
                $('.supplier_name').val($(this).find(':selected').text());
            }

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\QUARANTINE\CNG Transfer to PC\stack-n\stack-n\resources\views/stock/create.blade.php ENDPATH**/ ?>