<?php $__env->startSection('head'); ?>
    <style>
        .ui-autocomplete {
            position: absolute;
            z-index: 1000;
            cursor: default;
            padding: 0;
            margin-top: 2px;
            list-style: none;
            background-color: #ffffff;
            border: 1px solid #ccc;
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            border-radius: 5px;
            -webkit-box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
            -moz-box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
        }
        .ui-autocomplete > li {
            padding: 3px 20px;
        }
        .ui-autocomplete > li.ui-state-focus {
            background-color: #DDD;
        }
        .ui-helper-hidden-accessible {
            display: none;
        }
        .ui-menu-item a.ui-state-focus {
            background: #faa; !important;
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="card">
        <div class="card-header">
            Edit <strong>Stock/Product</strong>
        </div>
        <div class="card-body card-block">

            <form class="form-horizontal create_stock" role="form" method="POST" action="<?php echo e(route('stock.store')); ?>">
                <?php echo csrf_field(); ?>

                <div class="box-body">

                    <div class="row">

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Stock Category</label>
                                <input type="text" class="form-control search_category_name" placeholder="Type here ..." name="category_name" autocomplete="off" value="<?php echo e($stockDetail->category_name); ?>" disabled>
                                <span class="help-block search_category_name_empty" style="display: none;">No Results Found ...</span>
                                <input type="hidden" class="search_category_id" name="category_id" value="<?php echo e($stockDetail->category_id); ?>">
                            </div>
                        </div>

                    </div>

                    <div class="row">

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Stock/Product Name</label>
                                <input type="text" class="form-control" placeholder="Type here ..." name="stock_name" value="<?php echo e($stockDetail->stock_name); ?>">
                            </div>
                        </div>

                    </div>

                    <div class="row">


                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Purchase Cost / Unit</label><br>
                                <input type="text" class="form-control" name="purchase_cost" placeholder="0.00" value="<?php echo e($stockDetail->category_name); ?>">
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Selling Cost / Unit</label>
                                <input type="text" class="form-control" name="selling_cost" placeholder="0.00" value="<?php echo e($stockDetail->category_name); ?>">
                            </div>
                        </div>

                    </div>

                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="unit_type">Unit Type</label><br>

                                <select class="form-control change_supplier_name" name="unit_type" id="unit_type">
                                    <option selected="" disabled="" value=""> Select </option>
                                    <?php if($stockDetail->stock_unit->unit_type == 'kg'): ?>
                                        <option value="kg" selected="selected">Kilograms</option>
                                    <?php else: ?>
                                        <option value="kg">Kilograms</option>
                                    <?php endif; ?>
                                    <?php if($stockDetail->stock_unit->unit_type == 'lt'): ?>
                                        <option value="lt" selected="selected">Liters</option>
                                    <?php else: ?>
                                        <option value="lt">Liters</option>
                                    <?php endif; ?>
                                    <?php if($stockDetail->stock_unit->unit_type == 'pcs'): ?>
                                        <option value="pcs" selected="selected">Pieces</option>
                                    <?php else: ?>
                                        <option value="pcs">Pieces</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">



                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="supplier_id">Supplier Name</label><br>
                                <select class="form-control change_supplier_name" name="supplier_id" id="supplier_id">
                                    <option selected="" disabled="" value=""> Select </option>
                                    <option value="0">- Multiple suppliers -</option>
                                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($stockDetail->supplier_id == $value->supplier_id): ?>
                                            <option value="<?php echo e($value->id); ?>" selected="selected"><?php echo e($value->supplier_name); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($value->id); ?>" selected="selected"><?php echo e($value->supplier_name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="hidden" name="supplier_name" class="supplier_name">
                            </div>
                        </div>



                    </div>


                </div>
                <!-- /.box-body -->

                <div class="box-footer">
                    <button type="reset" class="btn btn-danger pull-left">Reset</button>
                    <button type="submit" class="btn btn-primary pull-right"><i class="fa fa-plus"></i> Add</button>
                </div>
            </form>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $( ".search_category_name" ).autocomplete({
            source: "/search/category_name",
            minLength: 1,
            response: function(event, ui) {
                if (ui.content.length === 0) {

                    $(this).parent().addClass('has-error');
                    $(this).next().removeClass('glyphicon-ok').addClass('glyphicon-remove');
                    $(".search_category_name_empty").show();
                    $('.form_submit').hide();

                } else {
                    $(".search_category_name_empty").hide();
                    $('.form_submit').show();
                }
            },
            select: function(event, ui) {

                $('.search_category_id').val(ui.item.id);

            }
        });
        $('.change_supplier_name').on('change' ,function(){

            if($(this).find(':selected').val() === 0){
                $('.supplier_name').val('');
            }
            else{
                $('.supplier_name').val($(this).find(':selected').text());
            }

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Current Projects\ISP MGT\stack-n\resources\views/stock/edit.blade.php ENDPATH**/ ?>