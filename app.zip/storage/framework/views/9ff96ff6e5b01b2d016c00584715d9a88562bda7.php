<div class="logo">
    <a href="#">
        <img src="/images/icon/logo.png" alt="Cool Admin" />
    </a>
</div>
<div class="menu-sidebar__content js-scrollbar1">
    <nav class="navbar-sidebar">
        <ul class="list-unstyled navbar__list">
            <li class="active has-sub">
                <a class="js-arrow" href="<?php echo e(route('dashboard')); ?>">
                    <i class="fas fa-tachometer-alt"></i>Dashboard</a>
            </li>
            <li class="has-sub">
                <a class="js-arrow" href="#">
                    <i class="fas fa-copy"></i>User Management</a>
                <ul class="list-unstyled navbar__sub-list js-sub-list">
                    <li>
                        <a href="<?php echo e(url('users')); ?>">Users</a>
                    </li>
                    <li>
                        <a href="#">Roles</a>
                    </li>
                    <li>
                        <a href="#">Permission</a>
                    </li>
                </ul>
            </li>
            <li class="webhas-sub">
                <a class="js-arrow" href="<?php echo e(route('rent.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>Rents
                </a>
            </li>
            <li class="webhas-sub">
                <a class="js-arrow" href="<?php echo e(route('driver.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>Drivers</a>
            </li>
            <li class="has-sub">
                <a class="js-arrow" href="<?php echo e(route('vehicle.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>Vehicles</a>
            </li>
            <li class="has-sub">
                <a class="js-arrow" href="<?php echo e(route('case.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>Cases</a>
            </li>
            <li class="has-sub">
                <a class="js-arrow" href="<?php echo e(route('damage.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>Damages</a>
            </li>
            <li class="has-sub">
                <a class="js-arrow" href="<?php echo e(route('transaction.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>Transactions</a>
            </li>

            <li class="has-sub">
                <a class="js-arrow" href="#">
                    <i class="fas fa-desktop"></i>Inventory</a>
                <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                    <li class="has-sub <?php if(Request::is('category/*')): ?> active <?php endif; ?>">
                        <a href="<?php echo e(route('category.index')); ?>">
                            <i class="fa fa-shopping-bag"></i> <span>Category</span>
                            <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                    </li>
                    <li class="has-sub <?php if(Request::is('stock/*')): ?> active <?php endif; ?>">
                        <a href="<?php echo e(route('stock.index')); ?>">
                            <i class="fa fa-shopping-bag"></i> <span>Stock/Product</span>
                            <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                    </li>
                    <li class="has-sub <?php if(Request::is('supplier/*')): ?> active <?php endif; ?>">
                        <a href="<?php echo e(route('supplier.index')); ?>">
                            <i class="fa fa-shopping-bag"></i> <span>Supplier</span>
                            <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                    </li>
                    <li class="has-sub <?php if(Request::is('supplier/*')): ?> active <?php endif; ?>">
                        <a href="<?php echo e(route('supplier.index')); ?>">
                            <i class="fa fa-shopping-bag"></i> <span>Supplier</span>
                            <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                    </li>
                    <li class="has-sub <?php if(Request::is('purchase/*')): ?> active <?php endif; ?>">
                        <a href="<?php echo e(route('purchase.index')); ?>">
                            <i class="fa fa-shopping-bag"></i> <span>Purchase</span>
                            <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                    </li>

                    <li class="has-sub <?php if(Request::is('sales/*')): ?> active <?php endif; ?>">
                        <a href="<?php echo e(route('sales.index')); ?>">
                            <i class="fa fa-shopping-bag"></i> <span>Sales</span>
                            <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                    </li>

                    <li class="has-sub <?php if(Request::is('customer/*')): ?> active <?php endif; ?>">
                        <a href="<?php echo e(route('customer.index')); ?>">
                            <i class="fa fa-shopping-bag"></i> <span>Customer</span>
                            <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                    </li>


                </ul>
            </li>
        </ul>

    </nav>
</div>


<?php /**PATH D:\QUARANTINE\CNG Transfer to PC\stack-n\stack-n\resources\views/layouts/Associate/sidemenu-desktop.blade.php ENDPATH**/ ?>