<!DOCTYPE html>
<html lang="en">


<head>
        <!-- Title Page-->
        <title>Login</title>
        <?php echo $__env->make('layouts.Associate.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('head'); ?>

</head>



<body class="animsition">
<?php echo $__env->yieldContent('content'); ?>




<?php echo $__env->make('layouts.Associate.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('js'); ?>

</body>

</html>
<!-- end document-->
<?php /**PATH D:\Current Projects\ISP MGT\stack-n\resources\views/auth/authLayout.blade.php ENDPATH**/ ?>