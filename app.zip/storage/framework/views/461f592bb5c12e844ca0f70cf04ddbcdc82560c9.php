


























<!DOCTYPE html>
<html lang="en">
<head>
<?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('head'); ?>

</head>
<body class="form">
<?php echo $__env->yieldContent('content'); ?>


<?php echo $__env->make('layouts.partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('js'); ?>


</body>
</html>
<?php /**PATH D:\CNG Project\resources\views/auth/authLayout.blade.php ENDPATH**/ ?>