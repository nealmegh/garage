<?php $__env->startSection('head'); ?>
    <!--  BEGIN CUSTOM STYLE FILE  -->
    <link href="<?php echo e(asset('base/assets/css/users/user-profile.css')); ?>" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('base/assets/css/widgets/modules-widgets.css')); ?>">
    <link href="<?php echo e(asset('base/plugins/apex/apexcharts.css')); ?>" rel="stylesheet" type="text/css">
    <!--  END CUSTOM STYLE FILE  -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content -->
<div class="row sales">
    <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 layout-top-spacing">

        <div class="user-profile layout-spacing">
            <div class="widget-content widget-content-area">
                <div class="d-flex justify-content-between">
                    <h3 class="">Driver Info</h3>
                    <a href="#" class="mt-2 edit-profile"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit-3"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg></a>
                </div>
                <div class="text-center user-info">
                    <img src="<?php echo e(asset('storage/'.$driver->details->driver_photo)); ?>" alt="avatar" style="max-width: 90px; height: 90px">
                    <p class=""><?php echo e($driver->user->name); ?></p>
                </div>
                <div class="user-info-list">

                    <div class="">
                        <ul class="contacts-block list-unstyled" style="max-width: 400px !important;">
                            <li class="contacts-block__item">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-coffee"><path d="M18 8h1a4 4 0 0 1 0 8h-1"></path><path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"></path><line x1="6" y1="1" x2="6" y2="4"></line><line x1="10" y1="1" x2="10" y2="4"></line><line x1="14" y1="1" x2="14" y2="4"></line></svg> NID: <span class="shadow-none badge badge-primary"><?php echo e($driver->details->nid); ?></span>
                            </li>
                            <li class="contacts-block__item">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-coffee"><path d="M18 8h1a4 4 0 0 1 0 8h-1"></path><path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"></path><line x1="6" y1="1" x2="6" y2="4"></line><line x1="10" y1="1" x2="10" y2="4"></line><line x1="14" y1="1" x2="14" y2="4"></line></svg> License Number: <span class="shadow-none badge badge-primary"><?php echo e($driver->license_number); ?></span>
                            </li>
                            <?php
                                $interval = now()->diffInDays(Carbon\Carbon::parse($driver->license_validity), false);
                            ?>
                            <li class="contacts-block__item">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-calendar"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>License Date:
                                <?php if($interval < 30 && $interval >= 0): ?>
                                    <span class="shadow-none badge badge-warning"><?php echo e(date('d-m-Y', strtotime($driver->license_validity))); ?></span>
                                <?php elseif($interval < 0): ?>
                                    <span class="shadow-none badge badge-danger"><?php echo e(date('d-m-Y', strtotime($driver->license_validity))); ?></span>
                                <?php else: ?>
                                    <span class="shadow-none badge badge-success"><?php echo e(date('d-m-Y', strtotime($driver->license_validity))); ?></span>
                                <?php endif; ?>
                            </li>

                            <li class="contacts-block__item">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-phone"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg> Phone Number:  <span class="shadow-none badge badge-primary"><?php echo e($driver->phone_number); ?></span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="widget widget-account-invoice-one">

            <div class="widget-heading">
                <h5 class="">Account Info</h5>
            </div>

            <div class="widget-content">
                <div class="invoice-box">

                    <div class="acc-total-info">
                        <h5>Balance</h5>
                        <p class="acc-amount"><?php echo e($total_due); ?></p>
                    </div>

                    <div class="inv-detail">
                        <div class="info-detail-1">
                            <p>Loans</p>
                            <p><?php echo e($loans); ?></p>
                        </div>
                        <div class="info-detail-2">
                            <p>Rent Due</p>
                            <p><?php echo e($due); ?></p>
                        </div>
                        <div class="info-detail-2">
                            <p>Damage Due</p>
                            <p><?php echo e($damage); ?></p>
                        </div>
                    </div>

                </div>
            </div>

        </div>

    </div>

    <div class="col-xl-8 col-lg-6 col-md-7 col-sm-12 layout-top-spacing">

        <div class="bio layout-spacing ">
            <div class="widget-content widget-content-area">
                <h3 class="">Important Pictures</h3>
                <div class="bio-skill-box">

                    <div class="row">

                        <div class="col-12 col-xl-6 col-lg-12 mb-xl-5 mb-5 ">

                            <div class="d-flex b-skills">
                                <div>
                                </div>
                                <div class="">
                                    <h5>License</h5>
                                    <p>
                                            <img src='<?php echo e(asset('storage/'.$driver->details->license_photo)); ?>' style="height: auto; width: 100%;">
                                            <a class="btn btn-primary"  href="<?php echo e(asset('storage/'.$driver->details->license_photo)); ?>" target="_blank">View</a>
                                    </p>
                                </div>
                            </div>

                        </div>

                        <div class="col-12 col-xl-6 col-lg-12 mb-xl-5 mb-5 ">

                            <div class="d-flex b-skills">
                                <div>
                                </div>
                                <div class="">
                                    <h5>NID</h5>
                                    <p>
                                        <img src='<?php echo e(asset('storage/'.$driver->details->nid_photo)); ?>' style="height: auto; width: 100%;">
                                        <a class="btn btn-primary"  href="<?php echo e(asset('storage/'.$driver->details->nid_photo)); ?>" target="_blank">View</a>
                                    </p>
                                </div>
                            </div>

                        </div>



                    </div>

                </div>

            </div>
        </div>

    </div>


</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('base/assets/js/widgets/modules-widgets.js')); ?>"></script>
    <script src="<?php echo e(asset('base/plugins/apex/apexcharts.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.base2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\QUARANTINE\CNG Transfer to PC\stack-n\stack-n\resources\views/backend/driver/show.blade.php ENDPATH**/ ?>