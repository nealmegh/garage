<?php $__env->startSection('content'); ?>

        <div class="card">
            <div class="card-header">
                Create <strong>Vehicle</strong>
            </div>
            <div class="card-body card-block">
                <form action="<?php echo e(route('vehicle.store')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                <?php echo csrf_field(); ?>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="type" class=" form-control-label">Select Vehicle Type</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <select name="type" id="type" class="form-control">
                                <option value="0">Please select</option>
                                <option value="1">CNG</option>
                                <option value="2">Micro-Bus</option>
                                <option value="3">Sedan</option>
                            </select>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="text-input" class=" form-control-label">Registration Number</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="registration_number" name="registration_number" placeholder="" class="form-control">
                            <small class="form-text text-muted">Eg. Dhaka Metro La 15-3593</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="tax_token" class=" form-control-label">Tax Token</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="tax_token" name="tax_token"  class="form-control">
                            <small class="help-block form-text">Tax Token</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="text-input" class=" form-control-label">Fitness Number</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="fitness_number" name="fitness_number" placeholder="Text" class="form-control">
                            <small class="form-text text-muted">Eg. Dhaka Metro La 15-3593</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="email-input" class=" form-control-label">Fitness Validity</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="fitness_validity" name="fitness_validity" placeholder="Enter Date" class="form-control date">
                            <small class="help-block form-text">Last Valid Date</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="text-input" class=" form-control-label">Insurance Number</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="insurance_number" name="insurance_number" placeholder="Text" class="form-control">
                            <small class="form-text text-muted">Eg. Dhaka Metro La 15-3593</small>
                        </div>
                    </div>









                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="email-input" class=" form-control-label">Insurance Validity</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="insurance_validity" name="insurance_validity" placeholder="Enter Date" class="form-control date">
                            <small class="help-block form-text">Last Valid Date</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="asset_value" class=" form-control-label">Asset Value</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="text" id="asset_value" name="asset_value" class="form-control ">
                            <small class="help-block form-text">Asset Value</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="registration_img" class=" form-control-label">Registration Photo</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="file" id="registration_img" name="registration_img"  class="form-control " >
                            <small class="help-block form-text">Registration Photo</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="tax_img" class=" form-control-label">Tax Token Photo</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="file" id="tax_img" name="tax_img"  class="form-control " >
                            <small class="help-block form-text">Tax Token Photo</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="fitness_img" class=" form-control-label">Fitness Photo</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="file" id="fitness_img" name="fitness_img"  class="form-control " >
                            <small class="help-block form-text">Fitness Photo</small>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="insurance_img" class=" form-control-label">Insurance Photo</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <input type="file" id="insurance_img" name="insurance_img"  class="form-control " >
                            <small class="help-block form-text">Insurance Photo</small>
                        </div>
                    </div>


















                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary btn-sm">
                            <i class="fa fa-dot-circle-o"></i> Submit
                        </button>
                        <button type="reset" class="btn btn-danger btn-sm">
                            <i class="fa fa-ban"></i> Reset
                        </button>
                    </div>
                </form>
            </div>

        </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

   <script>
       var nowDate = new Date();
       var today = new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 0, 0, 0, 0);
       $(function() {
           $('.date').daterangepicker({
               singleDatePicker: true,
               showDropdowns: true,
               minDate: today,
               locale: {
                   format: 'MM/DD/YYYY'
               }
           });
       });

   </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Current Projects\ISP MGT\stack-n\resources\views/backend/vehicle/create.blade.php ENDPATH**/ ?>