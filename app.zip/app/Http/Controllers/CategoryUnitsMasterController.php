<?php

namespace App\Http\Controllers;

use App\CategoryUnitsMaster;
use Illuminate\Http\Request;

class CategoryUnitsMasterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CategoryUnitsMaster  $categoryUnitsMaster
     * @return \Illuminate\Http\Response
     */
    public function show(CategoryUnitsMaster $categoryUnitsMaster)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CategoryUnitsMaster  $categoryUnitsMaster
     * @return \Illuminate\Http\Response
     */
    public function edit(CategoryUnitsMaster $categoryUnitsMaster)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CategoryUnitsMaster  $categoryUnitsMaster
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CategoryUnitsMaster $categoryUnitsMaster)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CategoryUnitsMaster  $categoryUnitsMaster
     * @return \Illuminate\Http\Response
     */
    public function destroy(CategoryUnitsMaster $categoryUnitsMaster)
    {
        //
    }
}
