<?php

namespace App\Http\Controllers;

use App\MeasuresMaster;
use Illuminate\Http\Request;

class MeasuresMasterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\MeasuresMaster  $measuresMaster
     * @return \Illuminate\Http\Response
     */
    public function show(MeasuresMaster $measuresMaster)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\MeasuresMaster  $measuresMaster
     * @return \Illuminate\Http\Response
     */
    public function edit(MeasuresMaster $measuresMaster)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\MeasuresMaster  $measuresMaster
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MeasuresMaster $measuresMaster)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\MeasuresMaster  $measuresMaster
     * @return \Illuminate\Http\Response
     */
    public function destroy(MeasuresMaster $measuresMaster)
    {
        //
    }
}
